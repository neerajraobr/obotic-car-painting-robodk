# Robotic Car Painting Cell Simulation

Yuktii AI Labs – Robotics Simulation Intern Assessment

| | |
|---|---|
| **Name** | Neeraj Rao B R |
| **Software used** | RoboDK |
| **Robot selected** | Universal Robots UR10e (6-axis) |
| **End-effector** | RoboDK Paint gun (TCP: X 50, Z 450 mm, 30° tilt) |
| **Car model** | [GrabCAD – Car](https://grabcad.com/library/car-84) |

![RoboDK station](Screenshots/robodk_station.png)

## Overview
A UR10e robot with a paint gun follows a taught linear (MoveL) path over a car body and paints the roof, bonnet and side panels. RoboDK's particle-spray simulation (`Spray_Add`) shows where the paint lands.

## Repository contents
```
├── Simulation_Files/
│   ├── Yuktii_Paintin_Car_Neeraj.rdk   # RoboDK station (robot, tool, car, targets, programs)
│   └── SprayOn.py                      # Edited spray macro (red paint, uniform sphere particles)
├── Screenshots/
├── Technical_Report.pdf
└── README.md
```

## How to run
1. Install [RoboDK](https://robodk.com/download) (the free licence is enough).
2. Open `Simulation_Files/Yuktii_Paintin_Car_Neeraj.rdk`.
3. Double-click the **MAIN** program. The spray turns on, the **PAINT** program runs, and red paint is deposited on the car.
4. Press **Esc** to clear the paint before running it again.

## Approach
- **Cell layout:** UR10e on a fixed base, with the car body (Part1) in front of it, inside the robot's 1,300 mm reach.
- **Targets:** taught with RoboDK's *Teach Target* by jogging the gun so it is roughly normal to the surface: HOME, Paint 1–23 and Target 25–28.
- **Trajectory:** linear MoveL raster passes that keep a constant standoff distance and gun orientation, with no change of robot configuration.
- **Spray:** `SprayOn.py` was edited to use `PARTICLE=SPHERE(4,8) STEP=8x8` and a red RGBA colour for both the near and far parts of the spray cone.
- **Collision checking:** RoboDK Collision Map (robot + gun vs. car).
- **Cycle time:** 15.1 s (simulated).

## Limitations / future work
The car was used at its native CAD size (not rescaled to 4.8 m), and one fixed UR10e covers only the top and one side. Next steps would be a 7th-axis rail or a second robot, an industrial paint robot, and automatically generated surface-following paths.
